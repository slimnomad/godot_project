extends Control

var happy_count: int = 0
var sad_count: int = 0
var total_count: int = 0

var happy_label: Label
var sad_label: Label
var total_label: Label
var face_container: FlowContainer
var click_button: Button
var clear_button: Button

const EYE_COLORS = [
	Color(0.1, 0.1, 0.7),
	Color(0.1, 0.5, 0.1),
	Color(0.4, 0.2, 0.05),
	Color(0.0, 0.6, 0.7),
	Color(0.6, 0.1, 0.6),
	Color(0.7, 0.3, 0.0),
	Color(0.05, 0.05, 0.05),
	Color(0.4, 0.6, 0.9),
]

func _ready() -> void:
	happy_label  = $VBoxLayout/TopBar/StatsContainer/HappyLabel
	sad_label    = $VBoxLayout/TopBar/StatsContainer/SadLabel
	total_label  = $VBoxLayout/TopBar/StatsContainer/TotalLabel
	face_container = $VBoxLayout/ScrollArea/FaceContainer
	click_button = $VBoxLayout/TopBar/ClickButton
	clear_button = $VBoxLayout/TopBar/ClearButton

	click_button.pressed.connect(_on_click_me_pressed)
	clear_button.pressed.connect(_on_clear_pressed)

	_style_button(click_button, Color(0.2, 0.5, 0.9))
	_style_button(clear_button, Color(0.6, 0.2, 0.2))

func _style_button(btn: Button, col: Color) -> void:
	var style = StyleBoxFlat.new()
	style.bg_color = col
	style.corner_radius_top_left    = 10
	style.corner_radius_top_right   = 10
	style.corner_radius_bottom_left = 10
	style.corner_radius_bottom_right = 10
	style.content_margin_left   = 12
	style.content_margin_right  = 12
	style.content_margin_top    = 8
	style.content_margin_bottom = 8
	btn.add_theme_stylebox_override("normal", style)

	var hover_style = style.duplicate()
	hover_style.bg_color = col.lightened(0.15)
	btn.add_theme_stylebox_override("hover", hover_style)

	var pressed_style = style.duplicate()
	pressed_style.bg_color = col.darkened(0.15)
	btn.add_theme_stylebox_override("pressed", pressed_style)

	btn.add_theme_color_override("font_color", Color.WHITE)

func _on_click_me_pressed() -> void:
	var num_faces = randi_range(1, 10)
	for i in range(num_faces):
		_spawn_face()
	_update_stats()

func _spawn_face() -> void:
	var radius    = randf_range(20.0, 150.0)
	var num_eyes  = randi_range(2, 6)
	var eye_color = EYE_COLORS[randi() % EYE_COLORS.size()]
	var is_happy  = randf() < 0.5

	var panel = Panel.new()
	var card_size = (radius + 20.0) * 2.0
	panel.custom_minimum_size = Vector2(card_size, card_size + 30)

	var card_style = StyleBoxFlat.new()
	card_style.bg_color = Color(0.18, 0.18, 0.24, 1.0)
	card_style.corner_radius_top_left    = 12
	card_style.corner_radius_top_right   = 12
	card_style.corner_radius_bottom_left = 12
	card_style.corner_radius_bottom_right = 12
	card_style.border_width_left   = 2
	card_style.border_width_right  = 2
	card_style.border_width_top    = 2
	card_style.border_width_bottom = 2
	card_style.border_color = Color(0.4, 0.4, 0.6, 0.5)
	panel.add_theme_stylebox_override("panel", card_style)

	face_container.add_child(panel)

	var face_scene = load("res://Face.tscn")
	var face: Node2D = face_scene.instantiate()
	panel.add_child(face)

	face.position = Vector2(card_size / 2.0, card_size / 2.0)
	face.setup(radius, num_eyes, eye_color, is_happy)

	var info_label = Label.new()
	info_label.text = ("%s  👁 %d" % ["😊" if is_happy else "😢", num_eyes])
	info_label.add_theme_font_size_override("font_size", 14)
	info_label.add_theme_color_override("font_color",
		Color(0.5, 1.0, 0.5) if is_happy else Color(1.0, 0.5, 0.5))
	info_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	info_label.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	info_label.position = Vector2(0, card_size)
	info_label.size = Vector2(card_size, 30)
	panel.add_child(info_label)

	if is_happy:
		happy_count += 1
	else:
		sad_count += 1
	total_count += 1

	face.scale = Vector2.ZERO
	panel.modulate.a = 0.0
	var tween = create_tween()
	tween.set_parallel(true)
	tween.tween_property(face, "scale", Vector2.ONE, 0.3).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tween.tween_property(panel, "modulate:a", 1.0, 0.25)

func _on_clear_pressed() -> void:
	for child in face_container.get_children():
		child.queue_free()
	happy_count = 0
	sad_count   = 0
	total_count = 0
	_update_stats()

func _update_stats() -> void:
	happy_label.text = "Happy: %d" % happy_count
	sad_label.text   = "Sad: %d"   % sad_count
	total_label.text = "Total: %d"  % total_count
