extends Node2D

var face_radius: float = 50.0
var eye_count: int = 2
var eye_color: Color = Color.BLACK
var is_happy: bool = true
var face_color: Color = Color.YELLOW

func setup(radius: float, num_eyes: int, e_color: Color, happy: bool) -> void:
	face_radius = radius
	eye_count = num_eyes
	eye_color = e_color
	is_happy = happy
	face_color = Color(
		randf_range(0.8, 1.0),
		randf_range(0.7, 0.95),
		randf_range(0.1, 0.5)
	)
	queue_redraw()

func _draw() -> void:
	_draw_face()

func _draw_face() -> void:
	draw_circle(Vector2(4, 4), face_radius, Color(0, 0, 0, 0.18))
	draw_circle(Vector2.ZERO, face_radius, face_color)
	draw_arc(Vector2.ZERO, face_radius, 0, TAU, 64, Color(0.2, 0.15, 0.0, 0.9), 2.5)
	_draw_eyes()
	_draw_mouth()

func _draw_eyes() -> void:
	var eye_area_radius = face_radius * 0.55
	var eye_size = face_radius * 0.13
	var start_angle: float
	var angle_step: float

	if eye_count == 1:
		start_angle = -PI / 2
		angle_step = 0.0
	else:
		var spread = min(PI * 0.8, (eye_count - 1) * 0.45)
		start_angle = -PI / 2 - spread / 2
		angle_step = spread / float(eye_count - 1)

	for i in range(eye_count):
		var angle = start_angle + i * angle_step
		var eye_pos = Vector2(
			cos(angle) * eye_area_radius * 0.7,
			sin(angle) * eye_area_radius * 0.6 - face_radius * 0.05
		)
		draw_circle(eye_pos, eye_size * 1.4, Color.WHITE)
		draw_circle(eye_pos, eye_size, eye_color)
		draw_circle(eye_pos + Vector2(eye_size * 0.15, eye_size * 0.1), eye_size * 0.45, Color.BLACK)
		draw_circle(eye_pos + Vector2(-eye_size * 0.25, -eye_size * 0.3), eye_size * 0.2, Color.WHITE)

func _draw_mouth() -> void:
	var mouth_y = face_radius * 0.38
	var mouth_width = face_radius * 0.55

	if is_happy:
		var points = PackedVector2Array()
		var segments = 24
		for i in range(segments + 1):
			var t = float(i) / float(segments)
			var angle = PI + t * PI
			var x = cos(angle) * mouth_width
			var y = mouth_y + sin(angle) * face_radius * 0.28
			points.append(Vector2(x, y))
		draw_polyline(points, Color(0.15, 0.05, 0.0), 3.0, true)

		var smile_fill = PackedVector2Array()
		smile_fill.append(Vector2(-mouth_width, mouth_y))
		for i in range(segments + 1):
			var t = float(i) / float(segments)
			var angle = PI + t * PI
			smile_fill.append(Vector2(cos(angle) * mouth_width, mouth_y + sin(angle) * face_radius * 0.28))
		smile_fill.append(Vector2(mouth_width, mouth_y))
		draw_colored_polygon(smile_fill, Color(0.8, 0.1, 0.15, 0.85))

		draw_circle(Vector2(-face_radius * 0.55, face_radius * 0.25), face_radius * 0.18, Color(1.0, 0.5, 0.5, 0.35))
		draw_circle(Vector2(face_radius * 0.55, face_radius * 0.25), face_radius * 0.18, Color(1.0, 0.5, 0.5, 0.35))
	else:
		var points = PackedVector2Array()
		var segments = 24
		for i in range(segments + 1):
			var t = float(i) / float(segments)
			var angle = t * PI
			var x = -mouth_width + t * mouth_width * 2
			var y = mouth_y + sin(angle) * face_radius * 0.22
			points.append(Vector2(x, y))
		draw_polyline(points, Color(0.15, 0.05, 0.0), 3.0, true)

		for side in [-1, 1]:
			var brow_x = side * face_radius * 0.32
			var brow_start = Vector2(brow_x - face_radius * 0.18 * side, -face_radius * 0.52)
			var brow_end = Vector2(brow_x + face_radius * 0.18 * side, -face_radius * 0.42 + side * face_radius * 0.06)
			draw_line(brow_start, brow_end, Color(0.2, 0.1, 0.0), 3.0, true)

		if eye_count >= 3:
			for i in range(min(2, eye_count)):
				var tear_x = (-0.3 + i * 0.6) * face_radius
				draw_circle(Vector2(tear_x, face_radius * 0.05), face_radius * 0.06, Color(0.4, 0.6, 1.0, 0.8))
